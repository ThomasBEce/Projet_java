package Projet.Main;
import java.time.LocalDate;
import java.util.ArrayList;

public class Main {
	
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Fonds Fonds1 = new Fonds("PF", 50);
	}
	
	

}
