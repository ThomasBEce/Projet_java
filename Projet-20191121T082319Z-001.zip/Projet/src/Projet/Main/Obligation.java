package Projet.Main;

public class Obligation {

}
